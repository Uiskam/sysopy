Zrobione zad2 i zad3
