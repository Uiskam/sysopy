Type 'make run' in console in order to run a program 
