#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string.h>

#define L_PYTAN 10

int main(void){
 int status,gniazdo,i;
 struct sockaddr_in ser,cli;
 char buf[200];
 char pytanie[]="abccbahhff";

 gniazdo = socket(AF_INET,SOCK_STREAM,0);
 if (gniazdo==-1) {printf("blad socket\n"); return 0;}

 memset(&ser, 0, sizeof(ser));
 ser.sin_family = AF_INET;
 ser.sin_port = htons(9000);//ustal taki sam numer portu jak w serwerze
 ser.sin_addr.s_addr = inet_addr("127.0.0.1");
 //nawiaz polaczenie z komputerem i usluga wskazana przez 'ser', zwroc status
 //...

 if (status<0) {printf("blad 01\n"); return 0;}
 for (i=0; i<L_PYTAN; i++){
  status = write(gniazdo, pytanie+i, 1);
  //odczytaj dane otrzymane z sieci, wpisz do tablicy 'buf' i wyświetl na standardowym wyjściu (ekranie)
  //...

 }
 printf ("\n");

close(gniazdo);  
printf("KONIEC DZIALANIA KLIENTA\n");
return 0;
}

